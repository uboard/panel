
$("select[name='network-io'],select[name='disk-io']").change(function(){
    var key = $(this).val(),type = $(this).attr('name')
    if(type == 'network-io'){
      if(key == 'all') key = '';
      bt.set_cookie('network_io_key',key);
    }else{
      bt.set_cookie('disk_io_key',key);
    }
});
$('.tabs-nav span').click(function () { 
  var indexs = $(this).index();
  $(this).addClass('active').siblings().removeClass('active')
  $('.tabs-content .tabs-item:eq('+ indexs +')').addClass('tabs-active').siblings().removeClass('tabs-active')
  $('.tabs-down select:eq('+ indexs +')').removeClass('hide').siblings().addClass('hide')
  switch(indexs){
    case 0:
      index.net.table.resize();
    break;
    case 1:
      index.iostat.table.resize();
    break;
  }
})



var interval_stop = false;
var index = {
    // 顾问服务弹窗
    consultancy_services:function(show) {
        var consultancy_cookies = bt.get_cookie('consultancy_cookies');
        if(consultancy_cookies) return false;
        if(show !== 0) return false;
        layer.open({
            type:1,
            title:'免费顾问服务',
            closeBtn:false,
            area:['600px','470px'],
            btn:['接受顾问服务','放弃顾问服务'],
            content:'<div style="padding: 30px 35px;">\
                <div style="text-align: center;margin-bottom: 20px;font-size: 20px;height: 40px;line-height: 40px;">\
                <span style="vertical-align: middle;margin-left: 10px;font-size:21px;">感恩您使用宝塔，我们为您提供专属客服服务</span></div>\
                <div style="font-size: 14px;line-height: 27px;padding: 20px;border: 1px solid #ececec;border-radius: 5px;background: #fcfcfc;color: #555;text-indent:2em;">\
                    <div style="text-indent: 2em;margin-bottom: 10px;">我们提供给您<span style="font-weight: bold;">【免费的顾问服务】</span>，确保您在使用宝塔面板过程中遇到紧急或者棘手的问题能第一时间找到专人协助您处理，我们期待与您沟通。</div>\
                    <div style="text-indent: 2em;margin-bottom: 10px;">如果您点<span style="font-weight: bold;">【接受顾问服务】</span>，您无需再做什么，我们会有专人致电联系您并加您为好友，让您可以在有疑问的时候能第一时间联系到专员。</div>\
                    <div style="text-indent: 2em;margin-bottom: 10px;">同时您也可以<span style="font-weight: bold;">【放弃顾问服务】</span>，在遇到问题的时候可以在我们官网论坛发言，我们也有论坛值守人员协助您处理。</div></div>\
                </div>',
            yes:function(indexs,layero){
                bt.send('set_user_adviser','auth/set_user_adviser ',{status:1},function(res){
                    bt.set_cookie('consultancy_cookies','1');
                    layer.close(indexs);
                    bt.msg(res)
                })
            },
            btn2:function(indexs,layero){
                layer.confirm('是否放弃免费顾问服务，放弃后在遇到问题的时候可以在我们官网论坛发言，我们也有论坛值守人员协助您处理。', {
                    title:'提示',
                    area:'400px',
                    btn: ['确认', '取消'],
                    icon: 0,
                    closeBtn:2,
                    yes: function () {
                        bt.send('set_user_adviser','auth/set_user_adviser ',{status:0},function(res){
                            bt.set_cookie('consultancy_cookies','1');
                            layer.close(indexs);
                            bt.msg(res)
                        })
                    }
                })
                return false
            }
        })
    },
    warning_list:[],
    warning_num:0,
    series_option:{},// 配置项
    chart_json:{}, // 所有图表echarts对象
    chart_view:{}, // 磁盘echarts对象
    disk_view:[], // 释放内存标记
    chart_result:null,
    release:false,
    load_config:[{
        title: '运行堵塞',
    	val: 90,
    	color: '#dd2f00'
    },{
        title: '运行缓慢',
    	val: 80,
    	color: '#ff9900'
    },{
        title: '运行正常',
    	val: 70,
    	color: '#20a53a'
    },{
        title: '运行流畅',
    	val: 30,
    	color: '#20a53a'
    }],
    release:false,
    interval: {
        limit: 10,
        count: 0,
        task_id: 0,
        start: function () {
            var _this = this;
            _this.count = 0;
            _this.task_id = setInterval(function () {
                if (_this.count >= _this.limit) {
                    _this.reload();
                    return;
                }
                _this.count++;
                if (!interval_stop) index.reander_system_info();
            }, 3000)
        },
        reload: function () {
            var _this = this;
            if (_this) clearInterval(_this.task_id);
            _this.start();
        }
    },
    net: {
        table: null,
        data: {
            uData: [],
            dData: [],
            aData: []
        },
        init: function () {
            //流量图表
            index.net.table = echarts.init(document.getElementById('NetImg'));
            var obj = {};
            obj.dataZoom = [];
            obj.unit = lan.index.unit + ':KB/s';
            obj.tData = index.net.data.aData;
            obj.formatter = function(config){
              var _config = config,_tips = '';
              for(var i=0;i < config.length;i++){
                if(typeof config[i].data == "undefined") return false
                _tips +=  '<span style="display: inline-block;width: 10px;height: 10px;margin-rigth:10px;border-radius: 50%;background: '+ config[i].color +';"></span>  '+ config[i].seriesName +'：'+ (parseFloat(config[i].data)).toFixed(2) + ' KB/s' + ( config.length-1 !== i?'<br />':'')
              }
              return "时间："+ _config[0].axisValue +"<br />" + _tips;
            }
            obj.list = [];
            obj.list.push({ name: lan.index.net_up, data: index.net.data.uData, circle: 'circle', itemStyle: { normal: { color: '#f7b851' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(255, 140, 0,1)' }, { offset: 1, color: 'rgba(255, 140, 0,.4' }], false) } }, lineStyle: { normal: { width: 1, color: '#f7b851' } } });
            obj.list.push({ name: lan.index.net_down, data: index.net.data.dData, circle: 'circle', itemStyle: { normal: { color: '#52a9ff' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(30, 144, 255,1)' }, { offset: 1, color: 'rgba(30, 144, 255,.4)' }], false) } }, lineStyle: { normal: { width: 1, color: '#52a9ff' } } });
            option = bt.control.format_option(obj)

            index.net.table.setOption(option);
            window.addEventListener("resize", function () {
                index.net.table.resize();
            });
        },
        add: function (up, down) {
            var _net = this;
            var limit = 8;
            var d = new Date()
            if (_net.data.uData.length >= limit) _net.data.uData.splice(0, 1);
            if (_net.data.dData.length >= limit) _net.data.dData.splice(0, 1);
            if (_net.data.aData.length >= limit) _net.data.aData.splice(0, 1);
            _net.data.uData.push(up);
            _net.data.dData.push(down);
            _net.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
        }
    },
    iostat: {
      table: null,
      data: {
          uData: [],
          dData: [],
          aData: [],
          tipsData:[]
      },
      init: function () {
          //流量图表
          index.iostat.table = echarts.init(document.getElementById('IoStat'));
          var obj = {};
          obj.dataZoom = [];
          obj.unit = lan.index.unit + ':MB/s';
          obj.tData = index.iostat.data.aData;
          obj.formatter = function(config){
            var _config = config,_tips = "时间："+ _config[0].axisValue +"<br />",options =  {
              read_bytes:  '读取字节数',
              read_count:  '读取次数 ',
              read_merged_count: '合并读取次数',
              read_time: '读取延迟',
              write_bytes:  '写入字节数',
              write_count:  '写入次数',
              write_merged_count: '合并写入次数',
              write_time: '写入延迟',
            },data = index.iostat.data.tipsData[config[0].dataIndex],list = ['read_count','write_count','read_merged_count','write_merged_count','read_time','write_time',]
            for(var i=0;i < config.length;i++){
              if(typeof config[i].data == "undefined") return false
              _tips +=  '<span style="display: inline-block;width: 10px;height: 10px;border-radius: 50%;background: '+ config[i].color +';"></span>&nbsp;&nbsp;<span>'+ config[i].seriesName +'：'+ (parseFloat(config[i].data)).toFixed(2) + ' MB/s' + '</span><br />'
            }
            $.each(list,function(index,item){
              _tips += '<span style="display: inline-block;width: 10px;height: 10px;"></span>&nbsp;&nbsp;<span style="'+ (item.indexOf('time') > -1?('color:'+ ((data[item] > 100 && data[item] < 1000)?'#ff9900':(data[item] >= 1000?'red':'#20a53a'))):'') +'">'+  options[item] +'：' +   data[item]  + (item.indexOf('time') > -1 ?' ms':' 次/秒')  +  '</span><br />'
            })
            return _tips;
          }
          obj.list = [];
          obj.list.push({ name: '读取字节数', data: index.iostat.data.uData, circle: 'circle', itemStyle: { normal: { color: '#FF4683' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(255,70,131,1)' }, { offset: 1, color: 'rgba(255,70,131,.4' }], false) } }, lineStyle: { normal: { width: 1, color: '#FF4683' } } });
          obj.list.push({ name: '写入字节数', data: index.iostat.data.dData, circle: 'circle', itemStyle: { normal: { color: '#6CC0CF' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(108,192,207,1)' }, { offset: 1, color: 'rgba(108,192,207,.4)' }], false) } }, lineStyle: { normal: { width: 1, color: '#6CC0CF' } } });
          option = bt.control.format_option(obj)
          index.iostat.table.setOption(option);
          window.addEventListener("resize", function () {
            index.iostat.table.resize();
          });
      },
      add: function (read, write,data) {
        var _disk = this;
        var limit = 8;
        var d = new Date()
        if (_disk.data.uData.length >= limit) _disk.data.uData.splice(0, 1);
        if (_disk.data.dData.length >= limit) _disk.data.dData.splice(0, 1);
        if (_disk.data.aData.length >= limit) _disk.data.aData.splice(0, 1);
        if (_disk.data.tipsData.length >= limit) _disk.data.tipsData.splice(0, 1);
        _disk.data.uData.push(read);
        _disk.data.dData.push(write);
        _disk.data.tipsData.push(data);
        _disk.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
      }
    },
    get_init: function () {
        var _this = this;
        _this.reander_system_info(function(rdata){
            // 负载悬浮事件
            $('#loadChart').hover(function () {
              var arry = [
                ['最近1分钟平均负载',rdata.load.one],
                ['最近5分钟平均负载',rdata.load.five],
                ['最近15分钟平均负载',rdata.load.fifteen]
              ],tips = '';
              $.each(arry || [],function (index,item){ 
                tips += item[0]+'：'+ item[1] +'</br>';
              })
              $.each(rdata.cpu_times || {},function (key,item){ 
                tips += key +'：'+ item +'</br>';
              })
              // '最近1分钟平均负载：' + rdata.load.one + '</br>最近5分钟平均负载：' + rdata.load.five + '</br>最近15分钟平均负载：' + rdata.load.fifteen + ''
              layer.tips(tips, this, { time: 0, tips: [1, '#999'] });
            }, function(){
                layer.closeAll('tips');
            })
            
            // cpu悬浮事件
            $('#cpuChart').hover(function () {
                var cpuText = '';
            	for (var i = 1; i < rdata.cpu[2].length + 1; i++) {
            		var cpuUse = parseFloat(rdata.cpu[2][i - 1] == 0 ? 0 : rdata.cpu[2][i - 1]).toFixed(1)
            		if (i % 2 != 0) {
            			cpuText += 'CPU-' + i + '：' + cpuUse + '%&nbsp;|&nbsp;'
            		} else {
            			cpuText += 'CPU-' + i + '：' + cpuUse + '%'
            			cpuText += `\n`
            		}
            	}
                
                layer.tips(rdata.cpu[3] + "</br>" + rdata.cpu[5] + "个物理CPU，" + (rdata.cpu[4]) + "个物理核心，" + rdata.cpu[1]+"个逻辑核心</br>"+ cpuText, this, { time: 0, tips: [1, '#999'] });
            }, function(){
                layer.closeAll('tips');
            })
            
            $('#memChart').hover(function(){
                $(this).append('<div class="mem_mask shine_green" title="点击清理内存"><div class="men_inside_mask"></div><div class="mem-re-con" style="display:block"></div></div>');
                $(this).find('.mem_mask .mem-re-con').animate({top:'5px'},400);
                $(this).next().hide();
            },function(){
                $(this).find('.mem_mask').remove()
                $(this).next().show();
            }).click(function(){
                var that = $(this);
                var data = _this.chart_result.mem;
                bt.show_confirm('真的要释放内存吗？', '<font style="color:red;">若您的站点处于有大量访问的状态，释放内存可能带来无法预测的后果，您确定现在就释放内存吗？</font>', function () {
                    _this.release = true
                    var option = JSON.parse(JSON.stringify(_this.series_option));
                    // 释放中...
            	    var count = ''
            	    var setInter = setInterval(function(){
            	        if(count == '...'){
            	            count = '.'
            	        }else{
            	            count += '.'
            	        }
            	        option.series[0].detail.formatter = "释放中" + count
            	        option.series[0].detail.fontSize = 15
            	        option.series[0].data[0].value = 0
            	        _this.chart_view.mem.setOption(option, true)
            	        that.next().hide()
            	    },400)
        	        // 释放接口请求 
        	        bt.system.re_memory(function (res) {
        	            that.next().show()
        	            clearInterval(setInter)
        	            option.series[0].detail = $.extend(option.series[0].detail,{
        	                formatter:"已释放\n"+ bt.format_size(data.memRealUsed - res.memRealUsed),
        	                lineHeight:18,
        	                padding:[5,0]
        	            })
            	        _this.chart_view.mem.setOption(option,true)
            	        setTimeout(function() {
            	            _this.release = false;
            	            _this.chart_result.mem = res;
            	            _this.chart_active('mem');
            	        }, 2000);
        	        })
                })
            })
            
            // 磁盘悬浮事件
            for(var i = 0; i < rdata.disk.length; i++){
                var disk = rdata.disk[i],texts = "基础信息</br>"
                texts += "文件系统：" + disk.filesystem + "</br>"
                texts += "类型：" + disk.type + "</br>"
                texts += "挂载点：" + disk.path + "</br>"
                texts += "<strong>Inode信息:</strong></br>"
                texts += "总数：" + disk.inodes[0] + "</br>"
                texts += "已用：" + disk.inodes[1] + "</br>"
                texts += "可用：" + disk.inodes[2] + "</br>"
                texts += "Inode使用率：" + disk.inodes[3] + "</br>"
                texts += "<strong>容量信息</strong></br>"
                texts += "容量：" + disk.size[0] + "</br>"
                texts += "已用：" + disk.size[1] + "</br>"
                texts += "可用：" + disk.size[2] + "</br>"
                texts += "使用率：" + disk.size[3] + "</br>"
                $("#diskChart" + i).data('title',texts).hover(function () {
                    layer.tips($(this).data('title'), this, { time: 0, tips: [1, '#999'] });
                }, function(){
                    layer.closeAll('tips');
                })
            }
            _this.get_server_info(rdata);
            if(rdata.installed === false) bt.index.rec_install();
            if (rdata.user_info.status) {
                var rdata_data = rdata.user_info.data;
                bt.set_cookie('bt_user_info',JSON.stringify(rdata.user_info));
                $(".bind-user").html(rdata_data.username);
            }
            else {
                $(".bind-weixin a").attr("href", "javascript:;");
                $(".bind-weixin a").click(function () {
                    bt.msg({ msg: '请先绑定宝塔账号!', icon: 2 });
                })
            }
        })
        $('')
        setTimeout(function () { _this.get_index_list() },400)
        setTimeout(function () { _this.net.init() }, 500);
        setTimeout(function () { _this.iostat.init() }, 500);
        setTimeout(function () { _this.interval.start()},700);
    },
    get_server_info: function(info) {
        // bt.system.get_total(function (info){
        var memFree = info.memTotal - info.memRealUsed;
        if (memFree < 64) {
            $("#messageError").show();
            $("#messageError").append('<p><span class="glyphicon glyphicon-alert" style="color: #ff4040; margin-right: 10px;">' + lan.index.mem_warning + '</span> </p>')
        }

        if (info.isuser > 0) {
            $("#messageError").show();
            $("#messageError").append('<p><span class="glyphicon glyphicon-alert" style="color: #ff4040; margin-right: 10px;"></span>' + lan.index.user_warning + '<span class="c7 mr5" title="此安全问题不可忽略，请尽快处理" style="cursor:no-drop"> [不可忽略]</span><a class="btlink" href="javascript:setUserName();"> [立即修改]</a></p>')
        }

        if (info.isport === true) {
            $("#messageError").show();
            $("#messageError").append('<p><span class="glyphicon glyphicon-alert" style="color: #ff4040; margin-right: 10px;"></span>当前面板使用的是默认端口[8888]，有安全隐患，请到面板设置中修改面板端口!<span class="c7 mr5" title="此安全问题不可忽略，请尽快处理" style="cursor:no-drop"> [不可忽略]</span><a class="btlink" href="/config"> [立即修改]</a></p>')
        }
        var _system = info.system;
        $("#info").html(_system);
        $("#running").html(info.time);
        if (_system.indexOf("Windows") != -1) {
            $(".ico-system").addClass("ico-windows");
        }
        else if (_system.indexOf("CentOS") != -1) {
            $(".ico-system").addClass("ico-centos");
        }
        else if (_system.indexOf("Ubuntu") != -1) {
            $(".ico-system").addClass("ico-ubuntu");
        }
        else if (_system.indexOf("Debian") != -1) {
            $(".ico-system").addClass("ico-debian");
        }
        else if (_system.indexOf("Fedora") != -1) {
            $(".ico-system").addClass("ico-fedora");
        }
        else {
            $(".ico-system").addClass("ico-linux");
        }
        // })
    },
    
    /**
     * @description 渲染系统信息
     * @param rdata 接口返回值
     * 
    */
    reander_system_info:function(callback){
        var _this = this;
        bt.system.get_net(function (res){
            _this.chart_result = res
            // 动态添加磁盘，并赋值disk_view
            if(_this.chart_view.disk == undefined){
    	        for (var i = 0; i < res.disk.length; i++) {
    	            var diskHtml = "<li class='rank col-xs-6 col-sm-3 col-md-3 col-lg-2 mtb20 circle-box text-center'><div id='diskName" + i +"'></div><div class='chart-li' id='diskChart" + i +"'></div><div id='disk" + i +"'></div></li>";
    	            $("#systemInfoList").append(diskHtml);
    	            _this.disk_view.push(echarts.init(document.querySelector("#diskChart" + i)));
    	        }
            }
            
            // 负载
    		var loadCount = Math.round((res.load.one / res.load.max) * 100) > 100 ? 100 : Math.round((res.load.one / res.load.max) * 100);
    		loadCount = loadCount < 0 ? 0 : loadCount;
    		var loadInfo = _this.chart_color_active(loadCount);
    		
            // cpu
    		var cpuCount = res.cpu[0];
            var cpuInfo = _this.chart_color_active(cpuCount);
    		
            // 内存
    	    var memCount = Math.round((res.mem.memRealUsed / res.mem.memTotal) * 1000) / 10; // 返回 memRealUsed 占 memTotal 的百分比
    	    var memInfo = _this.chart_color_active(memCount);
            bt.set_cookie('memSize',res.mem.memTotal)
    	    
    	    // 磁盘
    	    var diskList = res.disk;
    	    var diskJson = [];
    		for (var i = 0; i < diskList.length; i++) {
    			var ratio = diskList[i].size[3];
    			ratio = parseFloat(ratio.substring(0, ratio.lastIndexOf("%")));
    			var diskInfo = _this.chart_color_active(ratio)
    
                diskJson.push(diskInfo)
                
    		}
    		
            // chart_json存储最新数据
    		_this.chart_json['load'] = loadInfo;
    	    _this.chart_json['cpu'] = cpuInfo;
    	    _this.chart_json['mem'] = memInfo;
    		_this.chart_json['disk'] = diskJson
            // 初始化 || 刷新
            if(_this.chart_view.disk == undefined) {
                _this.init_chart_view()
            } else {
                _this.set_chart_data()
            }
            $('.rank .titles').show()
            
            var net_key = bt.get_cookie('network_io_key');
            if(net_key){
                res.up = res.network[net_key].up;
                res.down = res.network[net_key].down;
                res.downTotal = res.network[net_key].downTotal;
                res.upTotal = res.network[net_key].upTotal;
                res.downPackets = res.network[net_key].downPackets;
                res.upPackets = res.network[net_key].upPackets;
                res.downAll = res.network[net_key].downTotal;
                res.upAll = res.network[net_key].upTotal;
            }
            var net_option = '<option value="all">全部</option>';
            $.each(res.network,function(k,v){
                var act = (k == net_key)?'selected':'';
                net_option += '<option value="'+k+'" '+act+'>'+k+'</option>';
            });
    
            $('select[name="network-io"]').html(net_option);
        
            
            //刷新流量
            $("#upSpeed").html(res.up.toFixed(2) + ' KB');
            $("#downSpeed").html(res.down.toFixed(2) + ' KB');
            $("#downAll").html(bt.format_size(res.downTotal));
            $("#upAll").html(bt.format_size(res.upTotal));
            index.net.add(res.up, res.down);


            var disk_key = bt.get_cookie('disk_io_key') || 'ALL', disk_io_data = res.iostat[disk_key || 'ALL'],mb = 1048576,ioTime = disk_io_data.write_time>disk_io_data.read_time?disk_io_data.write_time:disk_io_data.read_time
            $('#readBytes').html(bt.format_size(disk_io_data.read_bytes))
            $('#writeBytes').html(bt.format_size(disk_io_data.write_bytes))
            $('#diskIops').html((disk_io_data.read_count + disk_io_data.write_count) +' 次')
            $('#diskTime').html(ioTime +' ms').css({'color':ioTime > 100 && ioTime < 1000?'#ff9900':ioTime >= 1000?'red':'#20a53a'})

            index.iostat.add((disk_io_data.read_bytes / mb).toFixed(2), (disk_io_data.write_bytes / mb).toFixed(2),disk_io_data);

            
            var disk_option = '';
            $.each(res.iostat,function(k,v){
                disk_option += '<option value="'+k+'" '+ (k == disk_key?'selected':'') +'>'+ (k == 'ALL'?'全部':k) +'</option>';
            });
            $('select[name="disk-io"]').html(disk_option);

            if (index.net.table) index.net.table.setOption({ xAxis: { data: index.net.data.aData }, series: [{ name: lan.index.net_up, data: index.net.data.uData }, { name: lan.index.net_down, data: index.net.data.dData }] });
            if (index.iostat.table) index.iostat.table.setOption({ xAxis: { data: index.iostat.data.aData }, series: [{ name: '读取字节数', data: index.iostat.data.uData }, { name: '写入字节数', data: index.iostat.data.dData }] });
            if(callback) callback(res)
        });
    },
    /**
     * @description 渲染画布视图
     * 
    */
    init_chart_view:function(){
         // 所有图表对象装进chart_view
        this.chart_view['load'] = echarts.init(document.querySelector("#loadChart"))
        this.chart_view['cpu'] = echarts.init(document.querySelector("#cpuChart"))
        this.chart_view['mem'] = echarts.init(document.querySelector("#memChart"))
        this.chart_view['disk'] = this.disk_view
        
        // 图表配置项
        this.series_option = {
    		series: [{
    			type: 'gauge',
    			startAngle: 90,
    			endAngle: -270,
          animationDuration: 1500,
          animationDurationUpdate: 1000,
    			radius: '99%',
    			pointer: {
    				show: false
    			},
    			progress: {
    				show: true,
    				overlap: false,
    				roundCap: true,
    				clip: false,
    			    itemStyle: {
    				    borderWidth: 1,
    				    borderColor: '#20a53a'
    			    }
    			},
    			axisLine: {
    				lineStyle: {
    					width: 7,
    					color: [[0, "rgba(204,204,204,0.5)"], [1, "rgba(204,204,204,0.5)"]]
    				}
    			},
    			splitLine: {
    				show: false,
    				distance: 0,
    				length: 10
    			},
    			axisTick: {
    				show: false
    			},
    			axisLabel: {
    				show: false,
    				distance: 50
    			},
    			data: [{
    				value: 0,
    				detail: {
    					offsetCenter: ['0%', '0%']
    				},
    				itemStyle: {
    					color: '#20a53a',
    					borderColor: '#20a53a'
    				},
    			}],
    			detail: {
    				width: 50,
    				height: 15,
            lineHeight:15,
    				fontSize: 17,
    				color: '#20a53a',
    				formatter: '{value}%',
    				fontWeight:'normal'
    			}
    		}]
    	};
    	this.set_chart_data()
    },
    /**
     * @description 赋值chart的数据
     * 
    */
    set_chart_data:function(){
        this.chart_active("load")
    	this.chart_active("cpu")
    	if(!this.release){
            this.chart_active("mem")
        }
    	for(var i = 0; i < this.chart_view.disk.length; i++){
    	    this.series_option.series[0].data[0].value = this.chart_json.disk[i].val
    	    this.series_option.series[0].data[0].itemStyle.color = this.chart_json.disk[i].color
    	    this.series_option.series[0].data[0].itemStyle.borderColor = this.chart_json.disk[i].color
    	    this.series_option.series[0].progress.itemStyle.borderColor = this.chart_json.disk[i].color
    	    this.series_option.series[0].detail.color = this.chart_json.disk[i].color
    	    this.chart_view.disk[i].setOption(this.series_option, true)
    	    $("#disk" + i).text(this.chart_result.disk[i].size[1] + " / " + this.chart_result.disk[i].size[0])
    	    $("#diskName" + i).text(this.chart_result.disk[i].path)
    	}
    },
    /**
     * @description 赋值chart的数据
     * 
    */
    chart_active:function(name){
        // 图表数据
        this.series_option.series[0].data[0].value = this.chart_json[name].val
        this.series_option.series[0].data[0].itemStyle.color = this.chart_json[name].color
        this.series_option.series[0].data[0].itemStyle.borderColor = this.chart_json[name].color
    	this.series_option.series[0].progress.itemStyle.borderColor = this.chart_json[name].color
    	this.series_option.series[0].detail.color = this.chart_json[name].color
    	
    	this.chart_view[name].setOption(this.series_option, true)
    	
        // 文字
    	var val = ""
    	switch (name) {
    	    case 'load':
    	        val = this.chart_json[name].title
    	        break;
    	    case 'cpu':
    	        val = this.chart_result.cpu[1] + ' 核心'
    	        break;
    	    case 'mem':
    	        val = this.chart_result.mem.memRealUsed + " / " + this.chart_result.mem.memTotal + "(MB)"
    	        break;
    	}
    	
    	$("#" + name).text(val)
    },
    /**
     * @description 赋值chart的颜色
     * 
    */
    chart_color_active:function(number){
        var activeInfo = {};
    	for (var i = 0; i < this.load_config.length; i++) {
    		if (number >= this.load_config[i].val) {
    			activeInfo = JSON.parse(JSON.stringify(this.load_config[i]));
    			break;
    		} else if (number <= 30) {
    			activeInfo = JSON.parse(JSON.stringify(this.load_config[3]));
    			break;
    		}
    	}
        activeInfo.val = number;
    	return activeInfo;
    },
    

    
    
    get_index_list: function () {
        bt.soft.get_index_list(function (rdata) {
            var con = '';
            var icon = '';
            var rlen = rdata.length;
            var clickName = '';
            var setup_length = 0;
            for (var i = 0; i < rlen; i++) {
                if (rdata[i].setup) {
                    setup_length++;
                    if (rdata[i].admin) {
                        clickName = ' onclick="bt.soft.set_lib_config(\'' + rdata[i].name + '\',\'' + rdata[i].title + '\')"';
                    }
                    else {
                        clickName = 'onclick="soft.set_soft_config(\'' + rdata[i].name + '\')"';
                    }
                    var icon = rdata[i].name;
                    if (bt.contains(rdata[i].name, 'php-')) {
                        icon = 'php';
                        rdata[i].version = '';
                    }
                    var status = '';
                    if (rdata[i].status) {
                        status = '<span style="color:#20a53a" class="glyphicon glyphicon-play"></span>';
                    } else {
                        status = '<span style="color:red" class="glyphicon glyphicon-pause"></span>'
                    }
                    con += '<div class="col-sm-3 col-md-3 col-lg-3" data-id="' + rdata[i].name + '">\
							<span class="spanmove"></span>\
							<div '+ clickName + '>\
							<div class="image"><img width="48" src="/static/img/soft_ico/ico-'+ icon + '.png"></div>\
							<div class="sname">'+ rdata[i].title + ' ' + rdata[i].version + status + '</div>\
							</div>\
						</div>'
                }
            }
            $("#indexsoft").html(con);
            //软件位置移动
            var softboxsum = 12;
            var softboxcon = '';
            if (setup_length <= softboxsum) {
                for (var i = 0; i < softboxsum - setup_length; i++) {
                    softboxcon += '<div class="col-sm-3 col-md-3 col-lg-3 no-bg"></div>'
                }
                $("#indexsoft").append(softboxcon);
            }
            $("#indexsoft").dragsort({ dragSelector: ".spanmove", dragBetween: true, dragEnd: saveOrder, placeHolderTemplate: "<div class='col-sm-3 col-md-3 col-lg-3 dashed-border'></div>" });

            function saveOrder() {
                var data = $("#indexsoft > div").map(function () { return $(this).attr("data-id"); }).get();
                data = data.join('|');
                bt.soft.set_sort_index(data)
            };
        })
    },
    re_server: function () {
        bt.open({
            type: 1,
            title: '重启服务器或者面板',
            area: '330px',
            closeBtn: 2,
            shadeClose: false,
            content: '<div class="rebt-con"><div class="rebt-li"><a data-id="server" href="javascript:;">重启服务器</a></div><div class="rebt-li"><a data-id="panel" href="javascript:;">重启面板</a></div></div>'
        })
        setTimeout(function () {
            $('.rebt-con a').click(function () {
                var type = $(this).attr('data-id');
                switch (type) {
                    case 'panel':
                        layer.confirm(lan.index.panel_reboot_msg, { title: lan.index.panel_reboot_title, closeBtn: 2, icon: 3 }, function () {
                            var loading = bt.load();
                            interval_stop = true;
                            bt.system.reload_panel(function (rdata) {
                                loading.close();
                                bt.msg(rdata);
                            });
                            setTimeout(function () { window.location.reload(); }, 3000);
                        });
                        break;
                    case 'server':
                        var rebootbox = bt.open({
                            type: 1,
                            title: lan.index.reboot_title,
                            area: ['500px', '280px'],
                            closeBtn: 2,
                            shadeClose: false,
                            content: "<div class='bt-form bt-window-restart'>\
									<div class='pd15'>\
									<p style='color:red; margin-bottom:10px; font-size:15px;'>"+ lan.index.reboot_warning + "</p>\
									<div class='SafeRestart' style='line-height:26px'>\
										<p>"+ lan.index.reboot_ps + "</p>\
										<p>"+ lan.index.reboot_ps_1 + "</p>\
										<p>"+ lan.index.reboot_ps_2 + "</p>\
										<p>"+ lan.index.reboot_ps_3 + "</p>\
										<p>"+ lan.index.reboot_ps_4 + "</p>\
									</div>\
									</div>\
									<div class='bt-form-submit-btn'>\
										<button type='button' class='btn btn-danger btn-sm btn-reboot'>"+ lan.public.cancel + "</button>\
										<button type='button' class='btn btn-success btn-sm WSafeRestart' >"+ lan.public.ok + "</button>\
									</div>\
								</div>"
                        });
                        setTimeout(function () {
                            $(".btn-reboot").click(function () {
                                rebootbox.close();
                            })
                            $(".WSafeRestart").click(function () {
                                var body = '<div class="SafeRestartCode pd15" style="line-height:26px"></div>';
                                $(".bt-window-restart").html(body);
                                $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_1 + "</p>");
                                bt.pub.set_server_status_by("name="+bt.get_cookie('serverType')+"&type=stop", function (r1) {
                                    $(".SafeRestartCode p").addClass('c9');
                                    $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_2 + "...</p>");
                                    bt.pub.set_server_status_by("name=mysqld&type=stop", function (r2) {
                                        $(".SafeRestartCode p").addClass('c9');
                                        $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_3 + "...</p>");
                                        bt.system.root_reload(function (rdata) {
                                            $(".SafeRestartCode p").addClass('c9');
                                            $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_4 + "...</p>");
                                            var sEver = setInterval(function () {
                                                bt.system.get_total(function () {
                                                    clearInterval(sEver);
                                                    $(".SafeRestartCode p").addClass('c9');
                                                    $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_5 + "...</p>");
                                                    setTimeout(function () {
                                                        layer.closeAll();
                                                    }, 3000);
                                                })
                                            }, 3000);
                                        })
                                    })
                                })
                            })
                        }, 100)
                        break;
                }
            })
        }, 100)
    },
    get_cloud_list: function () {
        $.post('/plugin?action=get_soft_list', { type: -1, p: 1, force: 1, cache: 1 }, function (rdata) {
          console.log("已成功从云端获取软件列表");
        });
    },
    /**
     * @description 获取时间简化缩写
     * @param {Numbre} dateTimeStamp 需要转换的时间戳
     * @return {String} 简化后的时间格式
    */
    get_simplify_time:function(dateTimeStamp){
        if(dateTimeStamp === 0) return '刚刚';
        if(dateTimeStamp.toString().length == 10)  dateTimeStamp = dateTimeStamp * 1000
        var minute = 1000 * 60,hour = minute * 60,day = hour * 24,halfamonth = day * 15,month = day * 30,now = new Date().getTime(),diffValue = now - dateTimeStamp;  
        if(diffValue < 0) return  '刚刚';
        var monthC = diffValue / month,weekC = diffValue / (7 * day),dayC = diffValue / day,hourC = diffValue / hour,minC = diffValue / minute;  
        if(monthC >= 1) {  
            result = "" + parseInt(monthC) + "月前";  
        } else if(weekC >= 1) {  
            result = "" + parseInt(weekC) + "周前";  
        } else if(dayC >= 1) {  
            result = "" + parseInt(dayC) + "天前";  
        } else if(hourC >= 1) {  
            result = "" + parseInt(hourC) + "小时前";  
        } else if(minC >= 1) {  
            result = "" + parseInt(minC) + "分钟前";  
        } else{  
            result = "刚刚";  
        }     
        return result;
    },
}
index.get_init();
index.consultancy_services()