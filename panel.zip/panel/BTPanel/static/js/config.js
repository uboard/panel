function modify_port_val(port){
	layer.open({
		type: 1,
		area: '400px',
		title: '修改端口',
		closeBtn:2,
		shadeClose: false,
		btn:['确认','取消'],
		content: '<div class="bt-form pd20 pd70" style="padding:20px 35px;">\
				<ul style="margin-bottom:10px;color:red;width: 100%;background: #f7f7f7;padding: 10px;border-radius: 5px;font-size: 12px;">\
					<li style="color:red;font-size:13px;">1、有安全组的服务器请提前在安全组放行新端口</li>\
					<li style="color:red;font-size:13px;">2、如果修改端口导致面板无法访问，请在SSH命令行通过bt命令改回原来的端口</li>\
				</ul>\
				<div class="line">\
	                <span class="tname" style="width: 70px;">面板端口</span>\
	                <div class="info-r" style="margin-left:70px">\
	                    <input name="portss" class="bt-input-text mr5" type="text" style="width:200px" value="'+ port +'">\
	                </div>\
                </div>\
                <div class="details" style="margin-top:5px;padding-left: 3px;">\
					<input type="checkbox" id="check_port">\
					<label style="font-weight: 400;margin: 3px 5px 0px;" for="check_port">我已了解</label>,<a target="_blank" class="btlink" href="https://www.bt.cn/bbs/thread-40037-1-1.html">如何放行端口？</a>\
				</div>\
			</div>',
		yes:function(index,layero){
			var check_port = $('#check_port').prop('checked'),_tips = '';
			if(!check_port){
				_tips = layer.tips('请勾选我已了解', '#check_port', {tips:[1,'#ff0000'],time:5000});
				return false;
			}
			layer.close(_tips);
			$('#banport').val($('[name="portss"]').val());
			var _data = $("#set-Config").serializeObject();
			_data['port'] = $('[name="portss"]').val();
			var loadT = layer.msg(lan.config.config_save,{icon:16,time:0,shade: [0.3, '#000']});
			$.post('/config?action=setPanel',_data,function(rdata){
				layer.close(loadT);
				layer.msg(rdata.msg,{icon:rdata.status?1:2});
				if(rdata.status){
					layer.close(index);
					setTimeout(function(){
						window.location.href = ((window.location.protocol.indexOf('https') != -1)?'https://':'http://') + rdata.host + window.location.pathname;
					},4000);
				}
			});
		},
		success:function(){
			$('#check_port').click(function(){
				layer.closeAll('tips');
			});
		}
	});
}
$.fn.serializeObject = function(){   
   var o = {};   
   var a = this.serializeArray();   
   $.each(a, function() {   
       if (o[this.name]) {   
           if (!o[this.name].push) {   
               o[this.name] = [o[this.name]];   
           }   
           o[this.name].push(this.value || '');   
       } else {   
           o[this.name] = this.value || '';   
       }   
   });   
   return o;   
};


//关闭面板
function ClosePanel(){
	layer.confirm(lan.config.close_panel_msg,{title:lan.config.close_panel_title,closeBtn:2,icon:13,cancel:function(){
		$("#closePl").prop("checked",false);
	}}, function() {
		$.post('/config?action=ClosePanel','',function(rdata){
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
			setTimeout(function(){window.location.reload();},1000);
		});
	},function(){
		$("#closePl").prop("checked",false);
	});
}

(function(){
	get_three_channel(function(res){
		$('#channel_auth').val(!res.user_mail.user_name && !res.dingding.dingding ? '邮箱未设置 | 钉钉未设置':(res.user_mail.user_name? '邮箱已设置':(res.dingding.dingding? '钉钉已设置': '')))
		get_login_send(function(rdata){
    	    $('#panel_report').val(!rdata.status ? '邮箱未设置 | 钉钉未设置':(rdata.msg.mail? '邮箱已设置':(rdata.msg.dingding? '钉钉已设置': '')))
    	});
	});
})()

function get_three_channel(callback){
	$.post('/config?action=get_settings',function(res){
		if(callback) callback(res);
	});
}
function get_login_send(callback){
    $.post('/config?action=get_login_send',function(res){
		if(callback) callback(res);
	});
}
function get_login_log(obj,callback){
    $.post('/config?action=get_login_log',obj,function(res){
		if(callback) callback(res);
	});
}
function set_login_send(obj,callback){
    if(obj.type == undefined) return false;
    $.post('/config?action=set_login_send',{'type':obj.type},function(res){
		if(callback) callback(res);
	});
}
function clear_login_send(obj,callback){
    if(obj.type == undefined) return false;
    $.post('/config?action=clear_login_send',{'type':obj.type},function(res){
		if(callback) callback(res);
	});
}
function login_ipwhite(obj,callback){
    if(obj.type == undefined) return false;
    $.post('/config?action=login_ipwhite',obj,function(res){
		if(callback) callback(res);
	});
}
function get_qrcode_data(callback){
	$.post('/config?action=get_qrcode_data',function(res){
		if(callback) callback(res);
	});
}
function get_two_verify(callback){
	$.post('/config?action=get_key',function(res){
		if(callback) callback(res);
	});
}
function set_two_step_auth(obj,callback){
	$.post('/config?action=set_two_step_auth',{act:obj.act?1:0},function(res){
		if(callback) callback(res);
	});
}

$(".set-submit").click(function(){
	var data = $("#set-Config").serialize();
	layer.msg(lan.config.config_save,{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=setPanel',data,function(rdata){
		layer.closeAll();
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
		if(rdata.status){
			setTimeout(function(){
				window.location.href = ((window.location.protocol.indexOf('https') != -1)?'https://':'http://') + rdata.host + window.location.pathname;
			},1500);
		}
	});
	
});


function modify_auth_path() {
    var auth_path = $("#admin_path").val();
    btn = "<button type='button' class='btn btn-success btn-sm' onclick=\"bindBTName(1,'b')\">确定</button>";
    layer.open({
        type: 1,
        area: "500px",
        title: "修改安全入口",
        closeBtn: 2,
        shift: 5,
        shadeClose: false,
        content: '<div class="bt-form bt-form pd20 pb70">\
                    <div class="line ">\
                        <span class="tname">入口地址</span>\
                        <div class="info-r">\
                            <input name="auth_path_set" class="bt-input-text mr5" type="text" style="width: 311px" value="'+ auth_path+'">\
                        </div></div>\
                        <div class="bt-form-submit-btn">\
                            <button type="button" class= "btn btn-sm btn-danger" onclick="layer.closeAll()"> 关闭</button>\
                            <button type="button" class="btn btn-sm btn-success" onclick="set_auth_path()">提交</button>\
                    </div></div>'
    })
}

function set_auth_path() {
    var auth_path = $("input[name='auth_path_set']").val();
    var loadT = layer.msg(lan.config.config_save, { icon: 16, time: 0, shade: [0.3, '#000'] });
    $.post('/config?action=set_admin_path', { admin_path: auth_path }, function (rdata) {
        layer.close(loadT);
        if (rdata.status) {
            layer.closeAll();
            $("#admin_path").val(auth_path);
        }

        setTimeout(function () { layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 }); }, 200);
    });
}

function syncDate() {
	var loadT = layer.msg(lan.config.config_sync,{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=syncDate','',function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:1});
		setTimeout(function(){
				window.location.reload();
			},1500);
	});
}

//PHP守护程序
function Set502(){
	var loadT = layer.msg(lan.public.the,{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=Set502','',function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	});
}

//绑定修改宝塔账号
function bindBTName(a,type){
	var titleName = lan.config.config_user_binding;
	if(type == "b"){
		btn = "<button type='button' class='btn btn-success btn-sm' onclick=\"bindBTName(1,'b')\">"+lan.config.binding+"</button>";
	}
	else{
		titleName = lan.config.config_user_edit;
		btn = "<button type='button' class='btn btn-success btn-sm' onclick=\"bindBTName(1,'c')\">"+lan.public.edit+"</button>";
	}
	if(a == 1) {
		p1 = $("#p1").val();
		p2 = $("#p2").val();
		var loadT = layer.msg(lan.config.token_get,{icon:16,time:0,shade: [0.3, '#000']});
		$.post("/ssl?action=GetToken", {username:p1,password:p2}, function(b){
			layer.close(loadT);
			layer.msg(b.msg, {icon: b.status?1:2});
			if(b.status) {
				window.location.reload();
				$("input[name='btusername']").val(p1);
			}
		});
		return
	}
	layer.open({
		type: 1,
		area: "290px",
		title: titleName,
		closeBtn: 2,
		shift: 5,
		shadeClose: false,
		content: "<div class='bt-form pd20 pb70'><div class='line'><span class='tname'>"+lan.public.user+"</span><div class='info-r'><input class='bt-input-text' type='text' name='username' id='p1' value='' placeholder='"+lan.config.user_bt+"' style='width:100%'/></div></div><div class='line'><span class='tname'>"+lan.public.pass+"</span><div class='info-r'><input class='bt-input-text' type='password' name='password' id='p2' value='' placeholder='"+lan.config.pass_bt+"' style='width:100%'/></div></div><div class='bt-form-submit-btn'><button type='button' class='btn btn-danger btn-sm' onclick=\"layer.closeAll()\">"+lan.public.cancel+"</button> "+btn+"</div></div>"
	})
}

//设置模板
function setTemplate(){
	var template = $("select[name='template']").val();
	var loadT = layer.msg(lan.public.the,{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=SetTemplates','templates='+template,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:5});
		if(rdata.status === true){
			$.get('/system?action=ReWeb',function(){});
			setTimeout(function(){
				window.location.reload();
			},3000);
		}
	});
}

//设置面板SSL
function setPanelSSL(){
	var status = $("#panelSSL").prop("checked");
	var loadT = layer.msg(lan.config.ssl_msg,{icon:16,time:0,shade: [0.3, '#000']});
	if(status){
		var confirm = layer.confirm('是否关闭面板SSL证书', {title:'提示',btn: ['确定','取消'],icon:0,closeBtn:2}, function() {
            bt.send('SetPanelSSL', 'config/SetPanelSSL', {}, function (rdata) {
                layer.close(loadT);
                if (rdata.status) {
                	layer.msg(rdata.msg,{icon:1});
                    $.get('/system?action=ReWeb', function () {
                    });
                    setTimeout(function () {
                        window.location.href = ((window.location.protocol.indexOf('https') != -1) ? 'http://' : 'https://') + window.location.host + window.location.pathname;
                    }, 1500);
                }
                else {
                    layer.msg(res.rdata,{icon:2});
                }
            });
            return;
        })
	}
	else {
        bt.send('get_cert_source', 'config/get_cert_source', {}, function (rdata) {
            layer.close(loadT);
            var sdata = rdata;
            var _data = {
                title: '面板SSL',
                area: '530px',
				class:'ssl_cert_from',
                list: [
                  {
                  		html:'<div><i class="layui-layer-ico layui-layer-ico3"></i><h3>'+lan.config.ssl_open_ps+'</h3><ul><li style="color:red;">'+lan.config.ssl_open_ps_1+'</li><li>'+lan.config.ssl_open_ps_2+'</li><li>'+lan.config.ssl_open_ps_3+'</li></ul></div>'
                  },
                    {
                        title: '类型',
                        name: 'cert_type',
                        type: 'select',
                        width: '200px',
                        value: sdata.cert_type,
                        items: [{value: '1', title: '自签证书'}, {value: '2', title: 'Let\'s Encrypt'}],
                        callback: function (obj) {
                            var subid = obj.attr('name') + '_subid';
                            $('#' + subid).remove();
                            if (obj.val() == '2') {
                                var _tr = bt.render_form_line({
                                    title: '管理员邮箱',
                                    name: 'email',
									width: '250px',
                                    placeholder: '管理员邮箱',
                                    value: sdata.email
                                });
                                obj.parents('div.line').append('<div class="line" id=' + subid + '>' + _tr.html + '</div>');
                            }
                        }
                    },
                  {
                  	html:'<div class="details"><input type="checkbox" id="checkSSL" /><label style="font-weight: 400;margin: 3px 5px 0px;" for="checkSSL">'+lan.config.ssl_open_ps_4+'</label><a target="_blank" class="btlink" href="https://www.bt.cn/bbs/forum.php?mod=viewthread&tid=4689">'+lan.config.ssl_open_ps_5+'</a></p></div>'
                  }
                  
                ],
                btns: [
                    {
                        title: '关闭', name: 'close', callback: function (rdata, load, callback) {
                            load.close();
                            $("#panelSSL").prop("checked", false);
                        }
                    },
                    {
                        title: '提交', name: 'submit', css: 'btn-success', callback: function (rdata, load, callback) {                                                    	
                          	if(!$('#checkSSL').is(':checked')){
                            	bt.msg({status:false,msg:'请先确认风险！'})
                              	return;
                            }                          
                        	var confirm = layer.confirm('是否开启面板SSL证书', {title:'提示',btn: ['确定','取消'],icon:0,closeBtn:2}, function() {
                            var loading = bt.load();
                            bt.send('SetPanelSSL', 'config/SetPanelSSL', rdata, function (rdata) {
                                loading.close()
                                if (rdata.status) {
                                	layer.msg(rdata.msg,{icon:1});
                                    $.get('/system?action=ReWeb', function () {
                                    });
                                    setTimeout(function () {
                                        window.location.href = ((window.location.protocol.indexOf('https') != -1) ? 'http://' : 'https://') + window.location.host + window.location.pathname;
                                    }, 1500);
                                }
                                else {
                                    layer.msg(rdata.msg,{icon:2});
                                }
                            })
							});
                        }

                    }
                ],
                end: function () {
                    $("#panelSSL").prop("checked", false);
                }
            };

            var _bs = bt.render_form(_data);
            setTimeout(function () {
                $('.cert_type' + _bs).trigger('change')
            }, 200);
        });
    }
}

function GetPanelSSL(){
	var loadT = layer.msg('正在获取证书信息...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=GetPanelSSL',{},function(cert){
		layer.close(loadT);
		var certBody = '<div class="tab-con">\
			<div class="myKeyCon ptb15">\
				<div class="ssl-con-key pull-left mr20">密钥(KEY)<br>\
					<textarea id="key" class="bt-input-text">'+cert.privateKey+'</textarea>\
				</div>\
				<div class="ssl-con-key pull-left">证书(PEM格式)<br>\
					<textarea id="csr" class="bt-input-text">'+cert.certPem+'</textarea>\
				</div>\
				<div class="ssl-btn pull-left mtb15" style="width:100%">\
					<button class="btn btn-success btn-sm" onclick="SavePanelSSL()">保存</button>\
				</div>\
			</div>\
			<ul class="help-info-text c7 pull-left">\
				<li>粘贴您的*.key以及*.pem内容，然后保存即可<a href="http://www.bt.cn/bbs/thread-704-1-1.html" class="btlink" target="_blank">[帮助]</a>。</li>\
				<li>如果浏览器提示证书链不完整,请检查是否正确拼接PEM证书</li><li>PEM格式证书 = 域名证书.crt + 根证书(root_bundle).crt</li>\
			</ul>\
		</div>'
		layer.open({
			type: 1,
			area: "600px",
			title: '自定义面板证书',
			closeBtn: 2,
			shift: 5,
			shadeClose: false,
			content:certBody
		});
	});
}

function SavePanelSSL(){
	var data = {
		privateKey:$("#key").val(),
		certPem:$("#csr").val()
	}
	var loadT = layer.msg(lan.config.ssl_msg,{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=SavePanelSSL',data,function(rdata){
		layer.close(loadT);
		if(rdata.status){
			layer.closeAll();
		}
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	});
}

function set_local() {
    var status_s = { false: '开启', true: '关闭' }
    var debug_stat = $("#panelLocal").prop('checked');
    bt.confirm({
		title: status_s[debug_stat] + "离线模式",
		msg: "您真的要"+ status_s[debug_stat] + "离线模式 ?",
	    cancel: function () {
			$("#panelLocal").prop('checked',debug_stat);
    	}}, function () {
        	var loadT = layer.msg(lan.public.the, { icon: 16, time: 0, shade: [0.3, '#000'] });
			$.post('/config?action=set_local', {}, function (rdata) {
				layer.close(loadT);
				if (rdata.status) layer.closeAll();
				layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
			});
        },function () {
		$("#panelLocal").prop('checked',debug_stat);
    });
}


if(window.location.protocol.indexOf('https') != -1){
	$("#panelSSL").attr('checked',true);
}
	
$(function () {
	$.get("/ssl?action=GetUserInfo", function (b) {
			if (b.status) {
					$("input[name='btusername']").val(b.data.username);
					$("input[name='btusername']").next().text(lan.public.edit).attr("onclick", "bindBTName(2,'c')").css({ "margin-left": "-82px" });
					$("input[name='btusername']").next().after('<span class="btn btn-xs btn-success" onclick="UnboundBt()" style="vertical-align: 0px;">' + lan.config.binding_un + '</span>');
			} else {
					$("input[name='btusername']").next().text(lan.config.binding).attr("onclick", "bindBTName(2,'b')").removeAttr("style");
			}
	});
})

function set_token_req(pdata,callback){
	$.post('/config?action=set_token', pdata, function (rdata) {
		if(callback) callback(rdata);
	});
}

function SetIPv6() {
    var loadT = layer.msg('正在配置,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] });
    $.post('/config?action=set_ipv6_status', {}, function (rdata) {
        layer.close(loadT);
        bt.msg(rdata);
    });
}

function set_panel_report(){
    var  loadB =  bt.load('正在打开告警设置!')
    get_three_channel(function(res){
        if(!res.user_mail.user_name && !res.dingding.dingding ) return layer.msg('请在消息通道中设置一个通道',{icon:2})
        get_login_send(function(rdata){
            loadB.close()
            layer.open({
    			type: 1,
    	        area:['750px', '603px'],
    	        title: "登录告警",
    	        closeBtn: 2,
    	        shift: 5,
    	        shadeClose: false,
    	        content: '<div class="bt-form">\
    	        			<div class="bt-w-main">\
    					        <div class="bt-w-menu">\
    					            <p class="bgw">服务状态</p>\
    					            <p>IP白名单</p>\
    					        </div>\
    					        <div class="bt-w-con pd15">\
    					            <div class="plugin_body">\
    	                				<div class="conter_box active" >\
    	                					<div class="bt-form" style="height:500px">\
    	                						<div class="line">\
    	                						    <span class="set-tit" style="display:inline-block;vertical-align: top;margin: 3px;color:#666" title="通知邮箱">通知邮箱</span>\
                    							    <div class="mail"  name="server_input" style="display:inline-block;margin:0px 10px 0px 0px">\
                                                        <input class="btswitch btswitch-ios" id="mail" type="checkbox" '+(!rdata.status?"":(rdata.msg.mail?"checked":""))+' >\
                                                         <label class="btswitch-btn" for="mail"></label>\
                                                    </div>\
                                                    <span class="set-tit" style="display:inline-block;vertical-align: top;margin: 3px;color:#666" title="通知钉钉">通知钉钉</span>\
                                                    <div class="dingding" name="server_input" style="display:inline-block;margin:0px 10px 0px 0px">\
                                                        <input class="btswitch btswitch-ios"  id="dingding" type="checkbox" '+(!rdata.status?"":(rdata.msg.dingding?"checked":""))+' >\
                                                        <label class="btswitch-btn" for="dingding"></label>\
                                                    </div>\
    	                						</div>\
    					                        <div class="line" style="max-height:400px;height:auto;overflow:auto">\
    						                        <div class="divtable">\
    						                        	<table class="table table-hover" width="100%" cellspacing="0" cellpadding="0" border="0"><thead><tr><th width="75%">详情</th><th width="25%" style="text-align:right">时间</th></tr></thead>\
    						                        	 <tbody id="server_table"></tbody>\
    						                        	</table>\
    						                        </div>\
    					                        </div>\
    					                        <div class="page" id="server_table_page"></div>\
    				                        </div>\
    				                        <ul class="mtl0 c7" style="font-size: 13px;position:absolute;bottom:0;padding-right: 40px;">\
                                    		   <li style="list-style:inside disc">邮箱通道和钉钉通道只能同时开启一个</li>\
                                        	</ul>\
    	                				</div>\
    	                				<div class="conter_box" style="display:none;height:500px">\
    		                				<div class="bt-form">\
    	                				    	<div class="line" style="display:inline-block">\
                                                    <input name="ip_write" class="bt-input-text mr5" type="text" style="width: 220px;height:35px" placeholder="请输入IP">\
                                                    <button class="btn btn-success btn-sm add_ip_write" style="height:35px;padding: 4px 15px">添加</button>\
    	                				    	</div>\
    	                				    	<div class="line" style="float:right">\
    	                							<button class="btn btn-default btn-sm clear_all" style="height:35px;padding: 4px 15px;text-align:right">清空全部</button>\
        	                					</div>\
        	                					 <div class="line" style="max-height:400px;height:auto;overflow:auto">\
    						                        <div class="divtable">\
    						                        	<table class="table table-hover" width="100%" cellspacing="0" cellpadding="0" border="0"><thead><tr><th width="60%">IP</th><th width="40%" style="text-align:right">操作</th></tr></thead>\
    						                        	 <tbody id="ip_write_table"></tbody>\
    						                        	</table>\
    						                        </div>\
    					                        </div>\
    				                        </div>\
    				                          <ul class="mtl0 c7" style="font-size: 13px;position:absolute;bottom:0;padding-right: 40px;">\
                                    		   <li style="list-style:inside disc">只允许设置ipv4白名单</li>\
                                        	</ul>\
    		            				</div>\
    	                			</div>\
    	                		</div>\
                    		</div>\
                    	  </div>',
        		success:function(index,layers){
        		    get_log_table();
        		    get_ip_write_table()
        		    $(".bt-w-menu p").click(function () {
                        var index = $(this).index();
                        $(this).addClass('bgw').siblings().removeClass('bgw');
                        $('.conter_box').eq(index).show().siblings().hide();
                    });
        		    //设置告警
        		    $('[name="server_input"] input,[name="server_input"] label').on('click',function(){
        		        var _type = $(this).attr('id'),_checked = $(this).prop('checked'),that = $(this);
        		        if(_type == 'mail'&& !res.user_mail.user_name ){ that.prop('checked',false); return  layer.msg('未设置邮件通道,请在消息通道中设置',{icon:2})}
        		        if(_type == 'dingding'&& !res.dingding.dingding ){that.prop('checked',false);  return  layer.msg('未设置钉钉通道,请在消息通道中设置',{icon:2})}
        		        if(_checked){
        		            set_login_send({type:_type},function(res){layer.msg(res.msg,{icon:res.status?1:2});})
        		        }else{
        		            clear_login_send({type:_type},function(res){layer.msg(res.msg,{icon:res.status?1:2});})
        		        }
        		        get_login_send(function(res){
    		                $('#mail').prop('checked',res.msg.mail)
    		                $('#dingding').prop('checked',res.msg.dingding)
        		        })
        		    });
        		    //添加
        		    $('.add_ip_write').on('click',function(){
        		        var _ip = $('[name="ip_write"]').val();
        		        if(['',undefined].includes(_ip)) return layer.msg('请输入正确的ip',{icon:2})
        		        login_ipwhite({ip:_ip,type:'add'},function(res){
        		            layer.msg(res.msg,{icon:res.status?1:2});
        		           if(res.status) get_ip_write_table()
        		        })
        		    })
        		    //删除ip白名单
        		    $('#ip_write_table').on('click','.del_ip_write',function(){
        		        var _ip = $(this).parents('tr').data().data;
        		        login_ipwhite({ip:_ip,type:'del'},function(res){
        		            layer.msg(res.msg,{icon:res.status?1:2});
        		            if(res.status) get_ip_write_table()
        		        })
        		    });
        		    //清空全部
        		    $('.clear_all').on('click',function(){
        		        login_ipwhite({type:'clear'},function(res){
        		            layer.msg(res.msg,{icon:res.status?1:2});
        		            if(res.status) get_ip_write_table()
        		        })
        		    })
        		    //分页操作
        		    $('#server_table_page').on('click','a',function(e){
        		        e.stopPropagation();
                        e.preventDefault();
        		        var _p = $(this).attr('href').match(/p=([0-9]*)/)[1];
        		        get_log_table({p:_p});
        		    })
        		},
        		cancel:function(){
            	   	get_three_channel(function(res){
                		$('#channel_auth').val(!res.user_mail.user_name && !res.dingding.dingding ? '邮箱未设置 | 钉钉未设置':(res.user_mail.user_name? '邮箱已设置':(res.dingding.dingding? '钉钉已设置': '')))
                		get_login_send(function(rdata){
                    	    $('#panel_report').val(!rdata.status ? '邮箱未设置 | 钉钉未设置':(rdata.msg.mail? '邮箱已设置':(rdata.msg.dingding? '钉钉已设置': '')))
                    	});
                	});
        		}
    		})
        })
    })
}
function get_log_table(obj){
    if(obj === undefined) obj = {p:1}
    var loadT = bt.load('正在获取日志列表')
    get_login_log(obj,function(res){
        loadT.close()
        $('#server_table').empty()
        $.each(res.data,function(index,item){
            $('#server_table').append($('<tr>\
                <td>'+ item.log +'</td>\
                <td style="text-align:right">'+ item.addtime +'</td>\
                </tr>').data({data:item,index:index}))
        });
        $('#server_table_page').html(res.page)
    });
}
function get_ip_write_table(){
    $('#ip_write_table').empty()
    var loadY = bt.load('正在获取ip列表')
    login_ipwhite({type:'get'},function(res){
        loadY.close()
        $.each(res.msg,function(index,item){
            $('#ip_write_table').append($('<tr>\
                <td>'+ item +'</td>\
                <td style="text-align:right">\
                    <a href="javascript:;" class="btlink del_ip_write" >删除</a>\
                </td>\
                </tr>').data({data:item,index:index}))
        });
    })
}
function open_three_channel_auth(){
	get_channel_settings(function(rdata){
		var isOpen = rdata.dingding.info.msg.isAtAll == 'True' ? 'checked': '';
		var isDing = rdata.dingding.info.msg == '无信息'? '': rdata.dingding.info.msg.dingding_url;
		layer.open({
			type: 1,
	        area: "600px",
	        title: "设置消息通道",
	        closeBtn: 2,
	        shift: 5,
	        shadeClose: false,
	        content: '<div class="bt-form">\
	        			<div class="bt-w-main">\
					        <div class="bt-w-menu">\
					            <p class="bgw">邮箱</p>\
					            <p>钉钉</p>\
					        </div>\
					        <div class="bt-w-con pd15">\
					            <div class="plugin_body">\
	                				<div class="conter_box active" >\
	                					<div class="bt-form">\
	                						<div class="line">\
	                							<button class="btn btn-success btn-sm" onclick="add_receive_info()">添加收件者</button>\
	                							<button class="btn btn-default btn-sm" onclick="sender_info_edit()">发送者设置</button>\
	                						</div>\
					                        <div class="line">\
						                        <div class="divtable">\
						                        	<table class="table table-hover" width="100%" cellspacing="0" cellpadding="0" border="0"><thead><tr><th>邮箱</th><th width="80px">操作</th></tr></thead></table>\
						                        	<table class="table table-hover"><tbody id="receive_table"></tbody></table>\
						                        </div>\
					                        </div>\
				                        </div>\
	                				</div>\
	                				<div class="conter_box" style="display:none">\
		                				<div class="bt-form">\
		                					<div class="line">\
												<span class="tname">通知全体</span>\
												<div class="info-r" style="height:28px; margin-left:100px">\
													<input class="btswitch btswitch-ios" id="panel_alert_all" type="checkbox" '+ isOpen+'>\
													<label style="position: relative;top: 5px;" class="btswitch-btn" for="panel_alert_all"></label>\
												</div>\
											</div>\
						        			<div class="line">\
					                            <span class="tname">钉钉URL</span>\
					                            <div class="info-r">\
					                                <textarea name="channel_dingding_value" class="bt-input-text mr5" type="text" style="width: 300px; height:90px; line-height:20px">'+isDing+'</textarea>\
					                            </div>\
					                            <button class="btn btn-success btn-sm" onclick="SetChannelDing()" style="margin: 10px 0 0 100px;">保存</button>\
					                        </div>\
				                        </div>\
		            				</div>\
	                			</div>\
	                		</div>\
                		</div>\
                	  </div>'
		})
		$(".bt-w-menu p").click(function () {
            var index = $(this).index();
            $(this).addClass('bgw').siblings().removeClass('bgw');
            $('.conter_box').eq(index).show().siblings().hide();
        });
		get_receive_list();
	})
}

function sender_info_edit(){
	var loadT = layer.msg('正在获取配置,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] });
	$.post('/config?action=get_settings',function(rdata){
		layer.close(loadT);
		var qq_mail = rdata.user_mail.info.msg.qq_mail == undefined ? '' : rdata.user_mail.info.msg.qq_mail,
			qq_stmp_pwd = rdata.user_mail.info.msg.qq_stmp_pwd == undefined? '' : rdata.user_mail.info.msg.qq_stmp_pwd,
			hosts = rdata.user_mail.info.msg.hosts == undefined? '' : rdata.user_mail.info.msg.hosts,
			port = rdata.user_mail.info.msg.port == undefined? '' : rdata.user_mail.info.msg.port
		layer.open({
		type: 1,
        area: "460px",
        title: "设置发送者邮箱信息",
        closeBtn: 2,
        shift: 5,
        shadeClose: false,
        content: '<div class="bt-form pd20 pb70">\
        	<div class="line">\
                <span class="tname">发送人邮箱</span>\
                <div class="info-r">\
                    <input name="channel_email_value" class="bt-input-text mr5" type="text" style="width: 300px" value="'+qq_mail+'">\
                </div>\
            </div>\
            <div class="line">\
                <span class="tname">smtp密码</span>\
                <div class="info-r">\
                    <input name="channel_email_password" class="bt-input-text mr5" type="password" style="width: 300px" value="'+qq_stmp_pwd+'">\
                </div>\
            </div>\
            <div class="line">\
                <span class="tname">smtp服务器</span>\
                <div class="info-r">\
                    <input name="channel_email_server" class="bt-input-text mr5" type="text" style="width: 300px" value="'+hosts+'">\
                </div>\
            </div>\
            <div class="line">\
                <span class="tname">端口</span>\
                <div class="info-r">\
                    <select class="bt-input-text mr5" id="port_select" style="width:'+(select_port(port)?'300px':'100px')+'"></select>\
                    <input name="channel_email_port" class="bt-input-text mr5" type="Number" style="display:'+(select_port(port)? 'none':'inline-block')+'; width: 190px" value="'+port+'">\
                </div>\
            </div>\
            <ul class="help-info-text c7">\
            	<li>推荐使用465端口，协议为SSL/TLS</li>\
            	<li>25端口为SMTP协议，587端口为STARTTLS协议</li>\
            </ul>\
            <div class="bt-form-submit-btn">\
	            <button type="button" class="btn btn-danger btn-sm smtp_closeBtn">关闭</button>\
	            <button class="btn btn-success btn-sm SetChannelEmail">保存</button></div>\
        	</div>',
        success:function(layers,index){
        	var _option = '';
        	if(select_port(port)){
        		if(port == '465' || port == ''){
        			_option = '<option value="465" selected="selected">465</option><option value="25">25</option><option value="587">587</option><option value="other">自定义</option>'
        		}else if(port == '25'){
        			_option = '<option value="465">465</option><option value="25" selected="selected">25</option><option value="587">587</option><option value="other">自定义</option>'
        		}else{
        			_option = '<option value="465">465</option><option value="25">25</option><option value="587" selected="selected">587</option><option value="other">自定义</option>'
        		}
        	}else{
        		_option = '<option value="465">465</option><option value="25">25</option><option value="587" >587</option><option value="other" selected="selected">自定义</option>'
        	}
        	console.log(port)
        	$("#port_select").html(_option)
        	$("#port_select").change(function(e){
        		if(e.target.value == 'other'){
        			$("#port_select").css("width","100px");
					$('input[name=channel_email_port]').css("display","inline-block");
        		}else{
        			$("#port_select").css("width","300px");
					$('input[name=channel_email_port]').css("display","none");
        		}
        	})
			$(".SetChannelEmail").click(function(){
				var _email = $('input[name=channel_email_value]').val();
				var _passW = $('input[name=channel_email_password]').val();
				var _server = $('input[name=channel_email_server]').val(),_port
				if($('#port_select').val() == 'other'){
					_port = $('input[name=channel_email_port]').val();
				}else{
					_port = $('#port_select').val()
				}
				if(_email == ''){
					return layer.msg('邮箱地址不能为空！',{icon:2});
				}else if(_passW == ''){
					return layer.msg('STMP密码不能为空！',{icon:2});
				}else if(_server == ''){
					return layer.msg('STMP服务器地址不能为空！',{icon:2})
				}else if(_port == ''){
					return layer.msg('请输入有效的端口号',{icon:2})
				}
				var loadT = layer.msg('正在生成邮箱通道中,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] });
				$.post('/config?action=user_mail_send',{email:_email,stmp_pwd:_passW,hosts:_server,port:_port},function(rdata){
					layer.close(loadT);
					layer.msg(rdata.msg,{icon:rdata.status?1:2})
					if(rdata.status){
						layer.close(index)
						get_channel_settings();
					}
				})
			})
			$(".smtp_closeBtn").click(function(){
				layer.close(index)
			})
		}
	})
	})
}
function select_port(port){
	switch(port){
		case '25':
			return true;
		case '465':
			return true;
		case '587':
			return true;
		case '':
			return true;
		default:
			return false
	}
}
function get_channel_settings(callback){
	var loadT = layer.msg('正在获取配置,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] });
	$.post('/config?action=get_settings',function(rdata){
		layer.close(loadT);
        if (callback) callback(rdata);
	})
}
function add_receive_info(){
	layer.open({
		type: 1,
        area: "400px",
        title: "添加收件者邮箱",
        closeBtn: 2,
        shift: 5,
        shadeClose: false,
        content: '<div class="bt-form pd20 pb70">\
	        <div class="line">\
	            <span class="tname">收件人邮箱</span>\
	            <div class="info-r">\
	                <input name="creater_email_value" class="bt-input-text mr5" type="text" style="width: 240px" value="">\
	            </div>\
	        </div>\
	        <div class="bt-form-submit-btn">\
	            <button type="button" class="btn btn-danger btn-sm smtp_closeBtn">关闭</button>\
	            <button class="btn btn-success btn-sm CreaterReceive">创建</button>\
	        </div>\
	        </div>',
        success:function(layers,index){
        	$(".CreaterReceive").click(function(){
        		var _receive = $('input[name=creater_email_value]').val(),_that = this;
				if(_receive != ''){
					var loadT = layer.msg('正在创建收件人列表中,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] });
					layer.close(index)
					$.post('/config?action=add_mail_address',{email:_receive},function(rdata){
						layer.close(loadT);
						// 刷新收件列表
						get_receive_list();
						layer.msg(rdata.msg,{icon:rdata.status?1:2});
					})
				}else{
					layer.msg('收件人邮箱不能为空！',{icon:2});
				}
        	})
        	
			$(".smtp_closeBtn").click(function(){
				layer.close(index)
			})
		}
	})
}
function get_receive_list(){
	$.post('/config?action=get_settings',function(rdata){
		var _html = '',_list = rdata.user_mail.mail_list;
		if(_list.length > 0){
			for(var i= 0; i<_list.length;i++){
				_html += '<tr>\
					<td>'+ _list[i] +'</td>\
					<td width="80px"><a onclick="del_email(\''+ _list[i] + '\')" href="javascript:;" style="color:#20a53a">删除</a></td>\
					</tr>'
			}
		}else{
			_html = '<tr>没有数据</tr>'
		}
		$('#receive_table').html(_html);
	})
	
}

function del_email(mail){
	var loadT = layer.msg('正在删除【'+mail+'】中,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] }),_this = this;
	$.post('/config?action=del_mail_list',{email:mail},function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2})
		_this.get_receive_list()
	})
}
// 设置钉钉
function SetChannelDing(){
	var _url = $('textarea[name=channel_dingding_value]').val();
	var _all = $('#panel_alert_all').prop("checked");
	if(_url != ''){
		var loadT = layer.msg('正在生成钉钉通道中,请稍候...', { icon: 16, time: 0, shade: [0.3, '#000'] });
		$.post('/config?action=set_dingding',{url:_url,atall:_all == true? 'True':'False'},function(rdata){
			layer.close(loadT);
			layer.msg(rdata.msg,{icon:rdata.status?1:2})
		})
	}else{
		layer.msg('请输入钉钉url',{icon:2})
	}
}

function get_panel_hide_list(){
	var loadT = bt.load('正在获取面板菜单栏目，请稍后..'),arry = [];
	$.post('/config?action=get_menu_list',function(rdata){
		loadT.close();
		$.each(rdata,function(index,item){
			if(!item.show) arry.push(item.title)
		});
		$('#panel_menu_hide').val(arry.length > 0?arry.join('、'):'无隐藏栏目');
	});

}

get_panel_hide_list();

// 设置面板菜单显示功能
function set_panel_ground(){
	var loadT = bt.load('正在获取面板菜单栏目，请稍后..');
	$.post('/config?action=get_menu_list',function(rdata){
		var html = '',arry = ["dologin","memuAconfig","memuAsoft","memuA"],is_option = '';
		loadT.close();
		$.each(rdata,function(index,item){
			is_option = '<div class="index-item" style="float:right;"><input class="btswitch btswitch-ios" id="'+ item.id +'0000" name="'+ item.id +'" type="checkbox" '+ (item.show?'checked':'') +'><label class="btswitch-btn" for="'+ item.id +'0000"></label></div>'
			
			if(item.id == 'dologin' || item.id == 'memuAconfig' || item.id == 'memuAsoft' || item.id == 'memuA') is_option = '不可操作';
			html += '<tr><td>'+ item.title +'</td><td><div style="float:right;">'+ is_option +'</div></td></tr>';
		});
		layer.open({
			type:1,
			title:'设置面板菜单栏目管理',
			area:['350px','530px'],
			shadeClose:false,
			closeBtn:2,
			content:'<div class="divtable softlist" id="panel_menu_tab" style="padding: 20px 15px;"><table class="table table-hover"><thead><tr><th>菜单栏目</th><th style="text-align:right;width:120px;">是否显示</th></tr></thead><tbody>'+ html +'</tbody></table></div>',
			success:function(){
				$('#panel_menu_tab input').click(function(){
					var arry = [];
					$(this).parents('tr').siblings().each(function(index,el){
						if($(this).find('input').length >0 && !$(this).find('input').prop('checked')){
							arry.push($(this).find('input').attr('name'));
						}
					});
					if(!$(this).prop('checked')){
						arry.push($(this).attr('name'));
					}
					var loadT = bt.load('正在设置面板菜单栏目显示状态，请稍后..');
					$.post('/config?action=set_hide_menu_list',{hide_list:JSON.stringify(arry)},function(rdata){
						loadT.close();
						if(!rdata.status) bt.msg(rdata);
					});
				});
			}
		});
	});
}

